import React from "react";

const Button = (props) => {
  return <button className="btn_marketplace" {...props}></button>;
};

export default Button;
