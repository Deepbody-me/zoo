# Zoomemory NFT game

ZooMemory is a decentralized game where users can play a game that not only pumps your memory, but also helps you win NFTs.
Won NFTs are collected, exchanged, bought and sold. 
Each user in the game will have their own virtual zoo where they can show off their collection of NFTs.

The revenue from NFT marketplace royalties will be used for restoration and maintenance of zoos in Ukraine.
In addition, collectors of the rarest NFTs can win special tickets for free visits to zoos, aquariums and dolphinariums. This will require the consent of the respective zoos.

Users will be able to support the zoos with donations. Information about these donations will be recorded in the blockchain and users will receive a special NFT for this, which they can display in their virtual zoo.

## Future Plans

1. NFT craft (breeding) - combine 2 common NFTs, pay some token and you will get uncommon NFT;
2. Lottery functionality with our token - twice a week. You just need to hold/stake $ZMC (zooMemoryCoin) token in order to be eligible for lottery (lottery rewards are token and tickets for zoo)
3. Token staking pool - combined staking between stakeholders in order to gain more rewards
4. NFT battle game - turn based game where characters will battle and winners will get rewards
5. Add more games - tetris, tic-tac-toe, sudoku, chess
6. Exclusive Zookeeper NFT - for most donated users

